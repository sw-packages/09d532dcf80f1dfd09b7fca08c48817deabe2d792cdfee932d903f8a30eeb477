/* This is an automatically generated file. Do not edit. */

/* ETenms-B5-H */

static const pdf_range cmap_ETenms_B5_H_ranges[] = {
{0x20,0x7e,0x1},
};

static pdf_cmap cmap_ETenms_B5_H = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "ETenms-B5-H",
	/* usecmap */ "ETen-B5-H", NULL,
	/* wmode */ 0,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	1, 1, (pdf_range*)cmap_ETenms_B5_H_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
